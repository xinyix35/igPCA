
from . import SelectionMethod, PosteriorMean, GMDRegression, BiCrossValidation, _spilt
from . import igPCA
from . import GMD
name = "igPCA"

all = [
    "GMD",
    "igPCA",
    "Selection",
]

__version__ = "1.0.0"
